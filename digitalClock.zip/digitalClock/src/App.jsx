import React, { useEffect, useState } from 'react'
import './App.css'
export default function App() {

  const [ampm, setAmPm] = useState("am")
  const [time, setTime] = useState({ hours: 0, minutes: 0, seconds: 0 });
  let date = new Date()

  useEffect(() => {
    // Initialize the clock to start at a specific time (e.g., 12:00:00)
    setTime({ hours: date.getHours(), minutes: date.getMinutes(), seconds: date.getSeconds() });

    const timeInterval = setInterval(() => {
      setTime((prevTime) => {
        let { hours, minutes, seconds } = prevTime;

        // Increment seconds
        seconds += 1;

        // Handle rollover for seconds
        if (seconds >= 60) {
          seconds = 0;
          minutes += 1;
        }

        // Handle rollover for minutes
        if (minutes >= 60) {
          minutes = 0;
          hours += 1;
        }

        // Handle rollover for hours
        if (hours >= 24) {
            hours = 1;
        }

        if(hours>=12){
          setAmPm("Pm")
        }
        return { hours, minutes, seconds };
      });
    }, 1000);

    // Cleanup interval on component unmount
    return () => clearInterval(interval);
  }, []);

  const formatTime = (unit) => (unit < 10 ? `0${unit}` : unit);



  return (
    <div className='container' style={{ height: "100vh", backgroundColor: "black" }}>
      <div className="digital-clock">
        <div className="hours">
          <h1>{formatTime(time.hours)}</h1>
        </div>
        <div className='sep'>
          <h1>:</h1>
        </div>
        <div className="mins">
          <h1> {formatTime(time.minutes)}</h1>
        </div>
        <div className='sep'>
          <h1>:</h1>
        </div>
        <div className="sec">
          <h1>{formatTime(time.seconds)}</h1>
        </div>
        <div className="ampm">
          <h1>{ampm}</h1>
        </div>

      </div>
    </div>
  )
}
